import {
  Text,
  SafeAreaView,
  StyleSheet,
  Image,
  TouchableOpacity,
  View,
  Alert,
  ScrollView,
} from 'react-native';

function App() {
  function alerta() {
    Alert.alert('Caminhada');
  }
  function alerta2() {
    Alert.alert('Trilha');
  }
  function alerta3() {
    Alert.alert('Montanha');
  }
  function alerta4() {
    Alert.alert('GPS');
  }
  function alerta5() {
    Alert.alert('Guia');
  }
  

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View >
        <Image style={styles.foto} source={require('./assets/1.png')} />
      </View>
      <TouchableOpacity style={styles.button} onPress={alerta}>
        <Text style={styles.texto}>Clique Aqui</Text>
      </TouchableOpacity>

      <View >
        <Image style={styles.foto} source={require('./assets/2.png')} />
      </View>
      <TouchableOpacity style={styles.button} onPress={alerta2}>
        <Text style={styles.texto}>Clique Aqui 2</Text>
      </TouchableOpacity>

      <View >
        <Image style={styles.foto} source={require('./assets/3.png')} />
      </View>
      <TouchableOpacity style={styles.button} onPress={alerta3}>
        <Text style={styles.texto}>Clique Aqui 3</Text>
      </TouchableOpacity>
      
      <View >
        <Image style={styles.foto} source={require('./assets/4.png')} />
      </View>
      <TouchableOpacity style={styles.button} onPress={alerta4}>
        <Text style={styles.texto}>Clique Aqui 4</Text>
      </TouchableOpacity>

      <View >
        <Image style={styles.foto} source={require('./assets/5.png')} />
      </View>
      <TouchableOpacity style={styles.button} onPress={alerta5}>
        <Text style={styles.texto}>Clique Aqui 5</Text>
      </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  foto:{
    width: 150,
    height: 150,
    alignSelf: 'center',
    marginTop: 10,
  },
  button:{
    backgroundColor:'#86cf74',
    borderRadius:7,
    padding:5,
    width:100,
    height:25,
    alignItems:'center',
    flexDirection: 'row',
    gap: 10,
    marginTop:10,
  },
});
export default App;
